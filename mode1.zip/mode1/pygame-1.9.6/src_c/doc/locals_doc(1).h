/* Auto generated file: with makeref.py .  Docs go in docs/reST/ref/ . */
#define DOC_PYGAMELOCALS "pygame constants"


/* Docs in a comment... slightly easier to read. */

/*

pygame.locals
pygame constants

*/